<?php
var_dump(gd_info());
?>