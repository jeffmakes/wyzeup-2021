<?php include 'dtr/dtr.php'; ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>PHP + CSS Dynamic Text Replacement Example</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="dtr/headings.css" rel="stylesheet" type="text/css" />
</head>
<body>
	<p>Replaced Heading:</p>
	
	<h1>PHP &amp; CSS Dynamic Text Replacement</h1>
	
</body>
</html>

<?php ob_end_flush(); ?>
